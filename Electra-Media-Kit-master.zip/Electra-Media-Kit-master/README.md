<p align="center">
    <img src="https://cdn.discordapp.com/attachments/575318354529746946/575318376529002547/ic_launcher.png"
        height="130">

# Electra Media Kit
These Electra logos and brand assets can be used for display in online services, retail establishments, press or other promotional purposes.
